# 디버깅 · 코딩 동아리 축제 미니게임

| 미션 | 폴더 |
|---|---|
| 01 고장 난 키보드 | `keyboard/` |
| 02 다른 색깔 찾기 | `color/` |
| 03 점프 맵 | `jump/` |
| 04 수행평가 표절 사건 | `detective/` |

## GitHub Pages로 올리는 법
1. GitHub에서 새 저장소를 **Public**으로 만든다 (예: `debugging`).
2. 이 폴더 안의 파일과 폴더를 **전부** 저장소에 업로드한다. (`index.html`이 저장소 맨 위에 있어야 함)
3. 저장소 **Settings → Pages**에서 Source를 `Deploy from a branch`, Branch를 `main` / `/ (root)`로 고르고 Save.
4. 1~2분 뒤 `https://내아이디.github.io/debugging/` 주소로 접속한다.
